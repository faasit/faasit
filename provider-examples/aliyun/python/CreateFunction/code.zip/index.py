def handler(event,context):
    return event