# -*- coding: utf8 -*-
import json
def main_handler(event, context):
    print("Received event: " + json.dumps(event, indent = 2))
    print("Received context: " + str(context))
    try:
        res = int(event['a']) + int(event['b'])
        return res
    except:
        return 'a or b is not defined.'